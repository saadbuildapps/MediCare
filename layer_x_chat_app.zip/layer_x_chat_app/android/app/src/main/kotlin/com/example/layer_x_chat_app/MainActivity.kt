package com.example.layer_x_chat_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
