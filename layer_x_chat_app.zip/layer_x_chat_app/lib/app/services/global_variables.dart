
/// Global variables for the LayerX app.
class GlobalVariables {
  static List<String> errorMessages = ['Failed, Try Again'];
  // static UserRole userRole = UserRole.DRIVER;
  static String route = '';
}
