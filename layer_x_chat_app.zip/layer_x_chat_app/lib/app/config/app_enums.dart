/// Defines enums for the LayerX app.
enum UserRole { USER, BUSINESS }
