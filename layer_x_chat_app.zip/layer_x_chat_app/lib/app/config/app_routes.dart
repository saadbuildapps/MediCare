import 'package:get/get.dart';
import 'package:layer_x_chat_app/app/mvvm/view/chat_view/chat_view.dart';
import 'package:layer_x_chat_app/app/mvvm/view/inbox_view/inbox_view.dart';
import 'package:layer_x_chat_app/app/mvvm/view/login_screen.dart';
import 'package:layer_x_chat_app/app/mvvm/view/sign_up_view/sign_up_view.dart';

import '../mvvm/view/all_user_view/all_user_view.dart';
import '../mvvm/view/splash_view/splash_view.dart';

/// Defines navigation routes for the LayerX app.
abstract class AppRoutes {
  AppRoutes._();

  static const splashView = '/splashView';
  static const loginView = '/loginView';
  static const signUpView = '/signUpView';
  static const inboxView = '/inboxView';
  static const chatView = '/chatView';
  static const allUserView = '/allUserView';

}

abstract class AppPages {
  AppPages._();

  static final routes = <GetPage>[
    GetPage(
      name: AppRoutes.splashView,
      page: () => SplashView(),
      binding: BindingsBuilder(() {
        // Get.lazyPut<GetStartedController>(() => GetStartedController());
      }),
    ),
    GetPage(
      name: AppRoutes.loginView,
      page: () => LoginView(),
      binding: BindingsBuilder(() {
        // Get.lazyPut<GetStartedController>(() => GetStartedController());
      }),
    ),
    GetPage(
      name: AppRoutes.signUpView,
      page: () => SignUpView(),
      binding: BindingsBuilder(() {
        // Get.lazyPut<GetStartedController>(() => GetStartedController());
      }),
    ),
    GetPage(
      name: AppRoutes.inboxView,
      page: () => ChatInboxView(),
      binding: BindingsBuilder(() {
        // Get.lazyPut<GetStartedController>(() => GetStartedController());
      }),
    ),
    GetPage(
      name: AppRoutes.chatView,
      page: () => AppChatView(),
      binding: BindingsBuilder(() {
        // Get.lazyPut<GetStartedController>(() => GetStartedController());
      }),
    ),

 GetPage(
      name: AppRoutes.allUserView,
      page: () => AllAppUsersView(),
      binding: BindingsBuilder(() {
        // Get.lazyPut<GetStartedController>(() => GetStartedController());
      }),
    ),



  ];
}


