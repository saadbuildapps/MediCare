/// Defines app configuration for the LayerX app.
class AppConfig {
  static const String appName = 'LayerX App';
}
