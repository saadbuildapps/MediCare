/// Defines asset paths for the LayerX app.
class AppAssets {
  static const String imagesPath = 'assets/images';
  static const String bgImage = '$imagesPath/bg_image.png';
}
