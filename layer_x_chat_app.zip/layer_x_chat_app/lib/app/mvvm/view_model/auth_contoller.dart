// Same imports as before
import 'dart:io';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:image_picker/image_picker.dart';
import 'package:layer_x_chat_app/app/config/app_colors.dart';
import 'package:layerx_fire_chat/mvvm/model/firebase_user_model.dart';
import 'package:layerx_fire_chat/mvvm/view_models/chat_controller.dart';
import 'package:layerx_fire_chat/repo/chat_repo.dart';
import '../../config/app_routes.dart';
import '../../repository/firebase/firebase_auth_repo.dart';
import '../../services/logger_service.dart';

enum Gender { male, female, other }

class AuthController extends GetxController {
  final AuthRepo _authRepo = AuthRepo();

  final emailController = TextEditingController();
  final passwordController = TextEditingController();
  final namecontroller = TextEditingController();

  final selectedGender = ''.obs;
  final isPasswordVisible = false.obs;
  final isLoading = false.obs;
  final firebaseUser = Rxn<User>();
  Rx<Gender> gender = Gender.male.obs;

  Rx<File> imageFile = File('').obs;

  @override
  void onInit() {
    super.onInit();
    firebaseUser.bindStream(_authRepo.authStateChanges());
    LoggerService.i('AuthController initialized');
  }

  void togglePasswordVisibility() {
    isPasswordVisible.value = !isPasswordVisible.value;
  }

  void setGender(String gender) {
    selectedGender.value = gender;
  }

  Future<void> login() async {
    isLoading.value = true;
    try {
      LoggerService.i('Attempting login for ${emailController.text}');
      await _authRepo.login(
        email: emailController.text.trim(),
        password: passwordController.text.trim(),
      );
      ChatController().saveUserId(userId: firebaseUser.value!.uid);
      LoggerService.i('Login successful');
      Get.snackbar('Success', 'Logged in successfully');
    } catch (err) {
      LoggerService.e('Login failed $err');
      Get.snackbar('Login Failed', err.toString());
    } finally {
      isLoading.value = false;
    }
  }

  FireBaseUserModel createFireBaseUserModel(String userAppId, String profilePicture) {
    return FireBaseUserModel(
      role: selectedGender.value,
      userEmail: emailController.text,
      userAppId: userAppId,
      userPhone: '',
      userName: namecontroller.text,
      status: 'online',
      profileImage: profilePicture,
      fcmToken: '',
      inboxIds: [],
    );
  }

  Future<File?> pickImageFromGallery() async {
    try {
      final pickedFile = await ImagePicker().pickImage(source: ImageSource.camera);
      if (pickedFile != null) {
        imageFile.value = File(pickedFile.path);
        LoggerService.i('Image selected: ${pickedFile.path}');
        return File(pickedFile.path);
      }
      LoggerService.w('No image selected');
      return null;
    } catch (err) {
      LoggerService.e('Image picking failed $err');
      return null;
    }
  }

  Future<UploadTask?> uploadImageToFirebase(String id) async {
    try {
      if (imageFile.value.path.isEmpty) {
        LoggerService.w('No image to upload');
        return null;
      }
      final storageRef = FirebaseStorage.instance.ref().child('userProfiles/$id');
      UploadTask uploadTask = storageRef.putFile(imageFile.value);
      LoggerService.i('Image upload started for user: $id');
      return uploadTask;
    } catch (err) {
      LoggerService.e('Image upload error $err');
      return null;
    }
  }

  Future<void> signUp() async {
    isLoading.value = true;
    try {
      LoggerService.i('Signing up user: ${emailController.text}');

      // 🔐 Sign up user using AuthRepo
      await _authRepo.signUp(
        email: emailController.text.trim(),
        password: passwordController.text.trim(),
      );

      String imageUrl = '';

      // ✅ Only upload image if selected
      if (imageFile.value.path.isNotEmpty) {
        LoggerService.v('Image upload started..');

        UploadTask? task = await uploadImageToFirebase(_authRepo.currentUser!.uid);

        if (task != null) {
          final snapshot = await task; // ✅ Wait for task to complete

          if (snapshot.state == TaskState.success) {
            imageUrl = await snapshot.ref.getDownloadURL();
            LoggerService.v('Image uploaded successfully. URL: $imageUrl');
          } else {
            LoggerService.e('Image upload failed with state: ${snapshot.state}');
          }
        } else {
          LoggerService.w('Upload task returned null; skipping image URL');
        }
      }

      // ✅ Add user data to Firestore
      await ChatRepo.addUserDataOnFirebase(
        userDataModel: createFireBaseUserModel(
          _authRepo.currentUser!.uid,
          imageUrl,
        ),
      );
      Get.offAllNamed(AppRoutes.inboxView);
      LoggerService.i('User created and data stored successfully');


      // 🎉 Success message
      Get.snackbar('Congratulations ✨', 'Account created successfully');

      clearAll();
    } catch (e, st) {
      LoggerService.e('Signup error $e', stackTrace: st);

      Get.snackbar(
        'Oops!',
        'An error occurred: $e',
        colorText: AppColors.white,
        backgroundColor: AppColors.negativeRed,
      );
    } finally {
      isLoading.value = false;
    }
  }

  Future<void> forgotPassword() async {
    if (emailController.text.trim().isEmpty) {
      Get.snackbar('Error', 'Please enter your email');
      return;
    }
    isLoading.value = true;
    try {
      await _authRepo.forgotPassword(email: emailController.text.trim());
      LoggerService.i('Password reset email sent to ${emailController.text}');
      Get.snackbar('Success', 'Reset link sent to your email');
    } catch (err) {
      LoggerService.e('Password reset failed $err');
      Get.snackbar('Failed', err.toString());
    } finally {
      isLoading.value = false;
    }
  }

  Future<void> logout() async {
    try {
      await _authRepo.logout();
      LoggerService.i('User logged out');
    } catch (err) {
      LoggerService.e('Logout failed $err');
      Get.snackbar('Error', err.toString());
    }
  }

  void clearAll() {
    emailController.clear();
    passwordController.clear();
    namecontroller.clear();
    imageFile.value = File('');
    selectedGender.value = '';
    isLoading.value = false;
    LoggerService.i('AuthController fields cleared');
  }

  @override
  void onClose() {
    emailController.dispose();
    passwordController.dispose();
    LoggerService.i('AuthController disposed');
    super.onClose();
  }
}
