import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:layerx_fire_chat/mvvm/model/firebase_user_model.dart';
import 'package:layerx_fire_chat/mvvm/view_models/chat_controller.dart';

class AllUsersController extends GetxController with GetTickerProviderStateMixin {
  final ChatController chatController = Get.find();

  late AnimationController fadeController;
  late Animation<double> fadeAnimation;

  final RxList<FireBaseUserModel> allUsers = <FireBaseUserModel>[].obs;
  final RxList<FireBaseUserModel> filteredUsers = <FireBaseUserModel>[].obs;
  final RxBool isLoading = true.obs;
  final RxBool hasError = false.obs;
  final RxString searchQuery = ''.obs;

  final TextEditingController searchController = TextEditingController();

  @override
  void onInit() {
    super.onInit();
    fadeController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );
    fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: fadeController, curve: Curves.easeOut),
    );
    fetchUsers();
    fadeController.forward();
  }

  void fetchUsers() async {
    isLoading.value = true;
    hasError.value = false;

    try {
      final users = await chatController.getAllUsersofFB();
      allUsers.assignAll(users);
      applyFilter();
    } catch (_) {
      hasError.value = true;
    } finally {
      isLoading.value = false;
    }
  }

  void applyFilter() {
    final query = searchQuery.value.toLowerCase();
    if (query.isEmpty) {
      filteredUsers.assignAll(allUsers);
    } else {
      filteredUsers.assignAll(
        allUsers.where((user) =>
        (user.userName?.toLowerCase().contains(query) ?? false) ||
            (user.userEmail?.toLowerCase().contains(query) ?? false) ||
            (user.userPhone?.contains(query) ?? false)),
      );
    }
  }

  void onSearchChanged(String value) {
    searchQuery.value = value;
    applyFilter();
  }

  bool isUserOnline(FireBaseUserModel user) {
    return user.status?.toLowerCase() == 'online';
  }

  String getStatusText(FireBaseUserModel user) {
    final status = user.status?.toLowerCase();
    if (status == 'online') return 'Online';
    if (status == 'offline') return 'Offline';
    return user.status ?? 'Unknown';
  }

  @override
  void onClose() {
    searchController.dispose();
    fadeController.dispose();
    super.onClose();
  }
}
