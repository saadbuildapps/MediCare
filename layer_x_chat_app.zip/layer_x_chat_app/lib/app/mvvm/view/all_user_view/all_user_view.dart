// --- main view file ---
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:layer_x_chat_app/app/widgets/bg_graphics.dart';
import 'package:layerx_fire_chat/mvvm/model/firebase_user_model.dart';
import 'package:custom_cached_image/custom_cached_image_with_shimmer.dart';
import 'package:layerx_fire_chat/utils/sizedbox_extension.dart';
import '../../../config/app_routes.dart';
import '../../../widgets/custom_status_widgets.dart';
import '../../view_model/all_users_controller.dart';


class AllAppUsersView extends StatelessWidget {
  AllAppUsersView({super.key});
  final AllUsersController controller = Get.put(AllUsersController());

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Color(0xFFF8FAFC), Color(0xFFE2E8F0)],
          ),
        ),
        child: Stack(
          children: [
            BgGraphics(),
            SafeArea(
              child: FadeTransition(
                opacity: controller.fadeAnimation,
                child: Column(
                  children: [
                    AllUsersHeader(controller: controller),
                    AllUsersSearchBar(controller: controller),
                    Expanded(
                      child: Obx(() {
                        if (controller.isLoading.value) return const LoadingView();
                        if (controller.hasError.value) return const ErrorView();
                        if (controller.filteredUsers.isEmpty) return const NoResultsView();
                        return ListView.builder(
                          padding: const EdgeInsets.fromLTRB(24, 16, 24, 20),
                          itemCount: controller.filteredUsers.length,
                          itemBuilder: (context, index) {
                            final user = controller.filteredUsers[index];
                            return UserCard(user: user, index: index, controller: controller);
                          },
                        );
                      }),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}




class AllUsersHeader extends StatelessWidget {
  final AllUsersController controller;

  const AllUsersHeader({super.key, required this.controller});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(24),
      child: Row(
        children: [
          IconButton(
            onPressed: () => Get.back(),
            icon: const Icon(Icons.arrow_back_ios, size: 20, color: Color(0xFF1E293B)),
            style: IconButton.styleFrom(
              backgroundColor: Colors.white.withOpacity(0.7),
              padding: const EdgeInsets.all(12),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            ),
          ),
          const SizedBox(width: 16),
          const Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('All Users', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w600, color: Color(0xFF1E293B))),
                Text('Find people to chat with', style: TextStyle(fontSize: 14, color: Color(0xFF64748B))),
              ],
            ),
          ),
          IconButton(
            onPressed: controller.fetchUsers,
            icon: const Icon(Icons.refresh, color: Color(0xFF1E293B), size: 20),
            style: IconButton.styleFrom(
              backgroundColor: Colors.white.withOpacity(0.7),
              padding: const EdgeInsets.all(12),
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
            ),
          ),
        ],
      ),
    );
  }
}


class AllUsersSearchBar extends StatelessWidget {
  final AllUsersController controller;

  const AllUsersSearchBar({super.key, required this.controller});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24),
      child: TextField(
        controller: controller.searchController,
        onChanged: controller.onSearchChanged,
        decoration: InputDecoration(
          hintText: 'Search by name, email or phone...',
          prefixIcon: const Icon(Icons.search, color: Color(0xFF64748B)),
          suffixIcon: Obx(() => controller.searchQuery.isNotEmpty
              ? IconButton(
            icon: const Icon(Icons.clear, color: Color(0xFF64748B)),
            onPressed: () {
              controller.searchController.clear();
              controller.onSearchChanged('');
            },
          )
              : 0.width),
          hintStyle: TextStyle(color: const Color(0xFF64748B).withOpacity(0.6), fontSize: 14),
          filled: true,
          fillColor: Colors.white.withOpacity(0.7),
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(16),
            borderSide: const BorderSide(color: Color(0xFF3B82F6), width: 2),
          ),
          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
        ),
      ),
    );
  }
}




class UserCard extends StatelessWidget {
  final FireBaseUserModel user;
  final int index;
  final AllUsersController controller;

  const UserCard({
    super.key,
    required this.user,
    required this.index,
    required this.controller,
  });

  @override
  Widget build(BuildContext context) {
    return TweenAnimationBuilder<double>(
      duration: Duration(milliseconds: 300 + (index * 100)),
      tween: Tween(begin: 0.0, end: 1.0),
      builder: (context, value, child) {
        return Opacity(
          opacity: value,
          child: Transform.translate(
            offset: Offset(0, 20 * (1 - value)),
            child: InkWell(
              onTap: () => controller.chatController.initChatWithUser(
                user.userAppId ?? '',
                route: AppRoutes.chatView,
                userName: user.userName ?? '',
                userImage: user.profileImage ?? '',
              ),
              borderRadius: BorderRadius.circular(16),
              child: Container(
                margin: const EdgeInsets.only(bottom: 12),
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.8),
                  borderRadius: BorderRadius.circular(16),
                  border: Border.all(color: const Color(0xFFE2E8F0).withOpacity(0.5)),
                ),
                child: Row(
                  children: [
                    Stack(
                      children: [
                        CustomCachedImage(
                          height: 60,
                          width: 60,
                          imageUrl: '${user.profileImage}',
                          borderRadius: 100,
                        ),
                        if (controller.isUserOnline(user))
                          Positioned(
                            bottom: 0,
                            right: 0,
                            child: Container(
                              width: 16,
                              height: 16,
                              decoration: BoxDecoration(
                                color: const Color(0xFF10B981),
                                shape: BoxShape.circle,
                                border: Border.all(color: Colors.white, width: 2),
                              ),
                            ),
                          ),
                      ],
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              Expanded(
                                child: Text(
                                  user.userName ?? 'Unknown User',
                                  style: const TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.w600,
                                    color: Color(0xFF1E293B),
                                  ),
                                ),
                              ),
                              if (user.role == 'admin')
                                Container(
                                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                                  decoration: BoxDecoration(
                                    color: const Color(0xFF3B82F6).withOpacity(0.1),
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                  child: const Text(
                                    'Admin',
                                    style: TextStyle(fontSize: 10, color: Color(0xFF3B82F6), fontWeight: FontWeight.w500),
                                  ),
                                ),
                            ],
                          ),
                          if (user.userEmail != null)
                            Text(user.userEmail!, style: _infoTextStyle()),
                          if (user.userPhone != null)
                            Text(user.userPhone!, style: _phoneTextStyle()),
                          const SizedBox(height: 4),
                          Text(
                            controller.getStatusText(user),
                            style: TextStyle(
                              fontSize: 12,
                              color: controller.isUserOnline(user)
                                  ? const Color(0xFF10B981)
                                  : const Color(0xFF64748B).withOpacity(0.6),
                              fontWeight: controller.isUserOnline(user) ? FontWeight.w500 : FontWeight.w400,
                            ),
                          ),
                        ],
                      ),
                    ),
                    Icon(Icons.chat_bubble_outline, size: 20, color: const Color(0xFF64748B).withOpacity(0.6)),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }

  TextStyle _infoTextStyle() => TextStyle(fontSize: 14, color: const Color(0xFF64748B).withOpacity(0.8));
  TextStyle _phoneTextStyle() => TextStyle(fontSize: 12, color: const Color(0xFF64748B).withOpacity(0.6));
}
