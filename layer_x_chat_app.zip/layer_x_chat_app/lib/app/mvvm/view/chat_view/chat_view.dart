import 'package:custom_cached_image/custom_cached_image_with_shimmer.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:layerx_fire_chat/mvvm/view/chat_view.dart';
import 'package:layerx_fire_chat/utils/padding_extensions.dart';
import 'package:layerx_fire_chat/widgets/message_bubble.dart';

import '../../../config/app_text_style.dart';

class AppChatView extends StatefulWidget {
  static const routeName = '/chat';

  const AppChatView({Key? key}) : super(key: key);

  @override
  State<AppChatView> createState() => _AppChatViewState();
}

class _AppChatViewState extends State<AppChatView> {
  late final String currentUserId;
  late final String chatBoxId;
  late final String receiverId;
  late final String userName;
  late final String userImage;

  @override
  void initState() {
    super.initState();

    final args = Get.arguments as Map<String, dynamic>;

    currentUserId = args['currentUserId'] ?? '';
    chatBoxId = args['chatBoxId'] ?? '';
    receiverId = args['receiverId'] ?? '';
    userName = args['userName'] ?? '';
    userImage = args['userImage'] ?? '';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading:  CustomCachedImage(height: 40.sp, width: 40.sp, imageUrl: userImage , borderRadius: 100.sp).paddingLeft(20.sp),
        leadingWidth: 80.w,
        title: Row(
          children: [
            Text(userName , style: AppTextStyles.customText24(),),
          ],
        ),

      ),
      body: ChatViewWidget(
       messageBubbleDecoration: MessageBubbleDecoration(),

        currentUserId: currentUserId,
        receiverId: receiverId,
        chatBoxId: chatBoxId,
        userName: userName,
        userImage: userImage,
      ),
    );
  }
}
