
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:layerx_fire_chat/mvvm/view_models/chat_controller.dart';

import '../../../config/app_colors.dart';
import '../../../config/app_text_style.dart';
import '../../../config/app_routes.dart';

class SplashView extends StatefulWidget {
  const SplashView({super.key});

  @override
  State<SplashView> createState() => _SplashViewState();
}

class _SplashViewState extends State<SplashView> with TickerProviderStateMixin {
  late AnimationController loadingController;

  @override
  void initState() {
    super.initState();

    if(FirebaseAuth.instance.currentUser == null) {
      Future.delayed(5000.ms, () {
      Get.offAllNamed(AppRoutes.loginView);
    });
    }else{
      Future.delayed(5000.ms, () {
        Get.offAllNamed(AppRoutes.inboxView);
      });
      ChatController().saveUserId(userId:FirebaseAuth.instance.currentUser!.uid);
    }


    loadingController = AnimationController(
      vsync: this,
      duration: 1500.ms,
    )..repeat();
  }

  @override
  void dispose() {
    loadingController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.white,
      body: Container(
        width: double.infinity,
        height: double.infinity,
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [
              Color(0xFFF8FAFC),
              Color(0xFFE2E8F0),
            ],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // App Name
            Text(
              'LayerX Chat',
              style: AppTextStyles.customText32(
                color: AppColors.black,
                fontWeight: FontWeight.w300,
              ),
            )
                .animate()
                .fadeIn(duration: 800.ms)
                .slideY(begin: 0.4, duration: 700.ms),

            16.h.verticalSpace,

            // Tagline
            Text(
              'Connect seamlessly, communicate effortlessly',
              textAlign: TextAlign.center,
              style: AppTextStyles.customText14(
                color: AppColors.lightTextColor,
                fontWeight: FontWeight.w400,
              ),
            )
                .animate()
                .fadeIn(duration: 800.ms)
                .slideY(begin: 0.5, duration: 700.ms)
                .then(delay: 200.ms),

            48.h.verticalSpace,

            // Animated Dots
            LoadingDots(controller: loadingController)
                .animate()
                .fadeIn(duration: 600.ms)
                .scale(begin: const Offset(0.9, 0.9), duration: 400.ms)
                .then(delay: 300.ms),
          ],
        ),
      ),
    );
  }
}

class LoadingDots extends StatelessWidget {
  final AnimationController controller;

  const LoadingDots({super.key, required this.controller});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 20.h,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: List.generate(3, (index) {
          return AnimatedBuilder(
            animation: controller,
            builder: (_, __) {
              final value = (controller.value - index * 0.2).clamp(0.0, 1.0);
              final scale = 1.0 + (0.3 * (1.0 - (value - 0.5).abs() * 2).clamp(0.0, 1.0));
              final opacity = 0.5 + (0.5 * (1.0 - (value - 0.5).abs() * 2).clamp(0.0, 1.0));

              return Container(
                margin: EdgeInsets.symmetric(horizontal: 4.w),
                child: Transform.scale(
                  scale: scale,
                  child: Container(
                    width: 8.w,
                    height: 8.w,
                    decoration: BoxDecoration(
                      color: AppColors.textLightBlack,
                      shape: BoxShape.circle,
                    ),
                  ),
                ),
              );
            },
          );
        }),
      ),
    );
  }
}
