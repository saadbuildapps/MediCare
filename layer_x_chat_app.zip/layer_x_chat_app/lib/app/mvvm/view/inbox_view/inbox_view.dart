import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:get/get.dart';
import 'package:layer_x_chat_app/app/config/app_routes.dart';
import 'package:layer_x_chat_app/app/config/app_text_style.dart';
import 'package:layer_x_chat_app/app/widgets/bg_graphics.dart';
import 'package:layerx_fire_chat/mvvm/view/inbox_view.dart';
import 'package:layerx_fire_chat/mvvm/view_models/chat_controller.dart';
import 'package:layerx_fire_chat/utils/sizedbox_extension.dart';
import 'package:layerx_fire_chat/widgets/inbox_tile.dart';

import '../../../config/app_colors.dart';

class ChatInboxView extends StatefulWidget {
  const ChatInboxView({super.key});

  @override
  State<ChatInboxView> createState() => _ChatInboxViewState();
}

class _ChatInboxViewState extends State<ChatInboxView> {
  final ChatController chatController = Get.find();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        actions: [
          ElevatedButton(
            style: ButtonStyle(backgroundColor: MaterialStateProperty.all(AppColors.lightTextColor)),
            onPressed: () {
              Get.toNamed(AppRoutes.allUserView);
            },
            child: Text('All Uses'),
          ),
          20.w.width,
        ],
        title: Text('Inbox', style: AppTextStyles.customText24()),
      ),
      backgroundColor: AppColors.bgColor,
      body: CustomBackGround(
        child: InboxViewWidget(
          onTileTap: (String id, String? name, String? imageUrl) {
            chatController.initChatWithUser(
                id,
                route: AppRoutes.chatView,
                userName: name,
                userImage: imageUrl);
          },
          inboxTileDecoration: InboxTileDecoration(), searchFieldDecoration: SearchFieldDecoration(),
        ),
      ),
    );
  }
}
