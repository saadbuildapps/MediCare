// Refactored SignUpView using LayerX style
// Using flutter_animate, AppColors, AppTextStyles, and CustomTextField

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';

import '../../../config/app_colors.dart';
import '../../../config/app_text_style.dart';
import '../../../widgets/custom_filed.dart';
import '../../view_model/auth_contoller.dart';



class SignUpView extends StatefulWidget {
  const SignUpView({super.key});

  @override
  State<SignUpView> createState() => _SignUpViewState();
}

class _SignUpViewState extends State<SignUpView> with TickerProviderStateMixin {
  final _formKey = GlobalKey<FormState>();

  final AuthController _authController = Get.put(AuthController());


  late final AnimationController _fadeCtrl = AnimationController(vsync: this, duration: 1000.ms);
  late final AnimationController _slideCtrl = AnimationController(vsync: this, duration: 800.ms);
  late final AnimationController _floatCtrl = AnimationController(vsync: this, duration: 3000.ms);

  late final Animation<double> _fadeAnim = Tween(begin: 0.0, end: 1.0).animate(
    CurvedAnimation(parent: _fadeCtrl, curve: Curves.easeOut),
  );

  late final Animation<Offset> _slideAnim = Tween(begin: const Offset(0, 0.3), end: Offset.zero).animate(
    CurvedAnimation(parent: _slideCtrl, curve: Curves.easeOutCubic),
  );

  late final Animation<double> _floatAnim = Tween(begin: 0.0, end: 1.0).animate(
    CurvedAnimation(parent: _floatCtrl, curve: Curves.easeInOut),
  );


  @override
  void initState() {
    super.initState();
    _startAnimations();
  }

  Future<void> _startAnimations() async {
    _fadeCtrl.forward();
    await 200.ms.delay();
    _slideCtrl.forward();
    _floatCtrl.repeat(reverse: true);
  }

  @override
  void dispose() {
    _fadeCtrl.dispose();
    _slideCtrl.dispose();
    _floatCtrl.dispose();

    super.dispose();
  }

  void _handleSignUp() async {
    if (_formKey.currentState!.validate() && _authController.selectedGender.value.isNotEmpty) {

      // Simulate sign-up API
     _authController.signUp();

    } else if (_authController.selectedGender.value == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please select your gender'),
          backgroundColor: Color(0xFFEF4444),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            colors: [Color(0xFFF8FAFC), Color(0xFFE2E8F0)],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: Stack(
          children: [
            _buildFloatingGraphics(),
            SafeArea(
              child: Center(
                child: SingleChildScrollView(
                  padding: EdgeInsets.symmetric(horizontal: 32.w),
                  child: FadeTransition(
                    opacity: _fadeAnim,
                    child: SlideTransition(
                      position: _slideAnim,
                      child: Column(
                        children: [
                          _buildHeader(),
                          40.h.verticalSpace,
                          _buildSignUpForm(),
                          24.h.verticalSpace,
                          _buildGenderSelector(),
                          22.h.verticalSpace,
                          _buildSignUpButton(),
                          24.h.verticalSpace,
                          _buildFooter(),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            )
          ],
        ),
      ),
    );
  }

  Widget _buildFloatingGraphics() {
    return Stack(
      children: [
        Positioned(
          top: -50.h,
          right: -30.w,
          child: AnimatedBuilder(
            animation: _floatAnim,
            builder: (_, __) => Transform.translate(
              offset: Offset(-10 * _floatAnim.value, 6 * _floatAnim.value),
              child: Container(
                width: 120.sp,
                height: 120.sp,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: AppColors.textLightBlack,
                ),
              ),
            ),
          ),
        ),
        Positioned(
          bottom: -60.h,
          left: -40.w,
          child: AnimatedBuilder(
            animation: _floatAnim,
            builder: (_, __) => Transform.translate(
              offset: Offset(8 * _floatAnim.value, -6 * _floatAnim.value),
              child: Container(
                width: 160.sp,
                height: 160.sp,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: AppColors.textLightBlack,
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildHeader() {
    return Column(
      children: [
        Text(
          'LayerX Chat',
          style: AppTextStyles.customText32(
            color: AppColors.black,
            fontWeight: FontWeight.w300,
          ),
        ),
        8.h.verticalSpace,
        Text(
          'Create your account',
          style: AppTextStyles.customText14(
            color: AppColors.lightTextColor,
          ),
        ),
      ],
    );
  }

  Widget _buildSignUpForm() {
    return Form(
      key: _formKey,
      child: Column(
        children: [
          Obx(
          ()=> GestureDetector(
              onTap: (){
                _authController.pickImageFromGallery();
              },
                child:
                    _authController.imageFile.value.path == ''?
                Icon(CupertinoIcons.person_alt_circle_fill, size: 120.sp, color: AppColors.white)
            : ClipRRect(
                        borderRadius: BorderRadius.circular(1000.r),
                        child: Image.file(_authController.imageFile.value, width: 120.sp, height: 120.sp, fit: BoxFit.cover,))
            ),
          ),
          20.h.verticalSpace,
          CustomTextField(
            controller: _authController.namecontroller,
            label: 'Full Name',
            hintText: 'Enter your full name',
            iconPath: Icons.person_outline,
            validator: (v) {
              if (v == null || v.isEmpty) return 'Please enter your name';
              if (v.length < 2) return 'Name must be at least 2 characters';
              return null;
            },
          ),
          20.h.verticalSpace,
          CustomTextField(
            controller: _authController.emailController,
            label: 'Email',
            hintText: 'Enter your email address',
            iconPath: Icons.email_outlined,
            keyboardType: TextInputType.emailAddress,
            validator: (v) {
              if (v == null || v.isEmpty) return 'Please enter your email';
              if (!RegExp(r'^[\w\.-]+@([\w-]+\.)+[\w-]{2,4}$').hasMatch(v)) return 'Enter valid email';
              return null;
            },
          ),
          20.h.verticalSpace,
          CustomTextField(
            controller: _authController.passwordController,
            label: 'Password',
            hintText: 'Create a strong password',
            iconPath: Icons.lock_outline,
            isPassword: true,
            validator: (v) {
              if (v == null || v.isEmpty) return 'Please enter password';
              if (v.length < 8) return 'Password must be at least 8 characters';
              return null;
            },
          )
        ],
      ),
    );
  }

  Widget _buildGenderSelector() {
    return Obx(
      ()=> Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Gender', style: AppTextStyles.customText12( fontWeight: FontWeight.w600, color: AppColors.black)),
          12.h.verticalSpace,
          Row(
            children: Gender.values.map((gender) {
              final isSelected = _authController.selectedGender.value == gender.name;
              return Expanded(
                child: GestureDetector(
                  onTap: () =>  _authController.selectedGender.value = gender.name,
                  child: Container(
                    margin: EdgeInsets.symmetric(horizontal: 4.w),
                    padding: EdgeInsets.symmetric(vertical: 16.h),
                    decoration: BoxDecoration(
                      color: isSelected ? AppColors.primary.withOpacity(0.1) : Colors.white,
                      borderRadius: BorderRadius.circular(12.r),
                      border: Border.all(
                        color: isSelected ? AppColors.primary : Colors.transparent,
                        width: 2,
                      ),
                    ),
                    child: Column(
                      children: [
                        Icon(
                          gender == Gender.male
                              ? Icons.male
                              : gender == Gender.female
                              ? Icons.female
                              : Icons.transgender,
                          color: isSelected ? AppColors.primary : AppColors.textLightBlack,
                        ),
                        8.h.verticalSpace,
                        Text(
                          gender.name.capitalizeFirst!,
                          style: AppTextStyles.customText12(
                            color: isSelected ? AppColors.primary : AppColors.textLightBlack,
                            fontWeight: isSelected ? FontWeight.w600 : FontWeight.w400,
                          ),
                        )
                      ],
                    ),
                  ),
                ),
              );
            }).toList(),
          ),
        ],
      ),
    );
  }

  Widget _buildSignUpButton() {
    return Obx(
      ()=> SizedBox(
        width: double.infinity,
        height: 56.h,
        child: ElevatedButton(
          onPressed: _authController.isLoading.value ? null : _handleSignUp,
          style: ElevatedButton.styleFrom(
            backgroundColor: AppColors.black,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12.r)),
          ),
          child: _authController.isLoading.value
              ? SizedBox(
            width: 20.w,
            height: 20.w,
            child: const CircularProgressIndicator(
              strokeWidth: 2,
              valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
            ),
          )
              : Text(
            'Create Account',
            style: AppTextStyles.customText16(
              color: Colors.white,
              fontWeight: FontWeight.w500,
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildFooter() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Text("Already have an account? ", style: AppTextStyles.customText14(color: AppColors.lightTextColor)),
        GestureDetector(
          onTap: () => Get.back(),
          child: Text(
            'Sign In',
            style: AppTextStyles.customText14(color: AppColors.primary, fontWeight: FontWeight.w500),
          ),
        )
      ],
    );
  }
}
