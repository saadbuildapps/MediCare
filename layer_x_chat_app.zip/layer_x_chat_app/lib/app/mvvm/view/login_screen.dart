


// Refactored LoginView using your coding style
// Responsive, Styled, Animated with CustomTextField

import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:get/get.dart';
import 'package:layer_x_chat_app/app/mvvm/view_model/auth_contoller.dart';
import 'package:layer_x_chat_app/app/repository/firebase/firebase_auth_repo.dart';

import '../../config/app_colors.dart';
import '../../config/app_text_style.dart';
import '../../config/app_routes.dart';
import '../../widgets/custom_filed.dart';

class LoginView extends StatefulWidget {
  const LoginView({Key? key}) : super(key: key);

  @override
  State<LoginView> createState() => _LoginViewState();
}

class _LoginViewState extends State<LoginView> with TickerProviderStateMixin {
  final _formKey = GlobalKey<FormState>();

  final AuthController _authController = AuthController();

  late AnimationController _fadeController;
  late AnimationController _slideController;
  late AnimationController _floatingController;

  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideAnimation;
  late Animation<double> _floatingAnimation;


  @override
  void initState() {
    super.initState();

    _fadeController = AnimationController(duration: 1000.ms, vsync: this);
    _slideController = AnimationController(duration: 800.ms, vsync: this);
    _floatingController = AnimationController(duration: 3000.ms, vsync: this);

    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _fadeController, curve: Curves.easeOut),
    );

    _slideAnimation = Tween<Offset>(begin: const Offset(0, 0.3), end: Offset.zero).animate(
      CurvedAnimation(parent: _slideController, curve: Curves.easeOutCubic),
    );

    _floatingAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _floatingController, curve: Curves.easeInOut),
    );

    _startAnimations();
  }

  void _startAnimations() async {
    _fadeController.forward();
    await 200.ms.delay();
    _slideController.forward();
    _floatingController.repeat(reverse: true);
  }

  @override
  void dispose() {
    _fadeController.dispose();
    _slideController.dispose();
    _floatingController.dispose();

    super.dispose();
  }

  void _handleLogin() async {
    if (_formKey.currentState!.validate()) {
       _authController.isLoading.value = true;


      AuthRepo().login(email:      _authController.emailController.text , password:      _authController.passwordController.text )
          .then((value) =>       Get.offAllNamed(AppRoutes.inboxView));

      setState(() =>      _authController.isLoading.value  = false);
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Login successful!'),
          backgroundColor: Color(0xFF10B981),
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: const BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Color(0xFFF8FAFC), Color(0xFFE2E8F0)],
          ),
        ),
        child: Stack(
          children: [
            _buildFloatingGraphics(),
            SafeArea(
              child: Center(
                child: SingleChildScrollView(
                  padding: EdgeInsets.symmetric(horizontal: 32.w),
                  child: FadeTransition(
                    opacity: _fadeAnimation,
                    child: SlideTransition(
                      position: _slideAnimation,
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          _buildHeader(),
                          48.h.verticalSpace,
                          _buildLoginForm(),
                          32.h.verticalSpace,
                          _buildLoginButton(),
                          24.h.verticalSpace,
                          _buildFooter(),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFloatingGraphics() {
    return Stack(
      children: [
        Positioned(
          top: -50.h,
          left: -30.w,
          child: AnimatedBuilder(
            animation: _floatingAnimation,
            builder: (_, __) => Transform.translate(
              offset: Offset(10 * _floatingAnimation.value, 5 * _floatingAnimation.value),
              child: Container(
                width: 220.sp,
                height: 220.sp,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: const Color(0xFFE2E8F0).withOpacity(0.3),
                ),
              ),
            ),
          ),
        ),
        Positioned(
          bottom: -60.h,
          right: -40.w,
          child: AnimatedBuilder(
            animation: _floatingAnimation,
            builder: (_, __) => Transform.translate(
              offset: Offset(-8 * _floatingAnimation.value, -6 * _floatingAnimation.value),
              child: Container(
                width: 260.sp,
                height: 260.sp,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: const Color(0xFFCBD5E1).withOpacity(0.2),
                ),
              ),
            ),
          ),
        ),
        Positioned(
          top: MediaQuery.of(context).size.height * 0.2,
          right: 20.w,
          child: AnimatedBuilder(
            animation: _floatingAnimation,
            builder: (_, __) => Transform.translate(
              offset: Offset(5 * _floatingAnimation.value, -8 * _floatingAnimation.value),
              child: Container(
                width: 60.w,
                height: 60.w,
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(16.r),
                  color: const Color(0xFFF1F5F9).withOpacity(0.6),
                ),
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildHeader() {
    return Column(
      children: [
        Text(
          'LayerX Chat',
          style: AppTextStyles.customText32(
            color: AppColors.black,
            fontWeight: FontWeight.w300,
          ),
        ),
        8.h.verticalSpace,
        Text(
          'Welcome back',
          style: AppTextStyles.customText14(
            color: AppColors.lightTextColor,
          ),
        ),
      ],
    );
  }

  Widget _buildLoginForm() {
    return Form(
      key: _formKey,
      child: Column(
        children: [
          CustomTextField(
            controller: _authController.emailController,
            label: 'Email',
            hintText: 'Enter your email address',
              iconPath: Icons.email_outlined,
            keyboardType: TextInputType.emailAddress,
            validator: (value) {
              if (value == null || value.isEmpty) return 'Please enter your email';
              if (!RegExp(r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$').hasMatch(value)) {
                return 'Please enter a valid email';
              }
              return null;
            },
          ),
          20.h.verticalSpace,
          CustomTextField(
            controller: _authController.passwordController,
            label: 'Password',
            hintText: 'Enter your password',
            iconPath: Icons.lock_outline,
            isPassword: true,
            // onToggleVisibility: () => setState(() => _isPasswordVisible = !_isPasswordVisible),
            validator: (value) {
              if (value == null || value.isEmpty) return 'Please enter your password';
              if (value.length < 6) return 'Password must be at least 6 characters';
              return null;
            },
          ),
        ],
      ),
    );
  }

  Widget _buildLoginButton() {
    return SizedBox(
      width: double.infinity,
      height: 56.h,
      child: ElevatedButton(
        onPressed:_authController.isLoading.value ? null : _handleLogin,
        style: ElevatedButton.styleFrom(
          backgroundColor: AppColors.black,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12.r)),
          elevation: 0,
        ),
        child: _authController.isLoading.value
            ? SizedBox(
          width: 20.w,
          height: 20.w,
          child: const CircularProgressIndicator(
            strokeWidth: 2,
            valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
          ),
        )
            : Text(
          'Sign In',
          style: AppTextStyles.customText16(
            color: AppColors.white,
            fontWeight: FontWeight.w500,
          ),
        ),
      ),
    );
  }

  Widget _buildFooter() {
    return Column(
      children: [
        InkWell(
          onTap: () {},
          child: Text(
            'Forgot Password?',
            style: AppTextStyles.customText14(color: AppColors.lightTextColor),
          ),
        ),
        10.h.verticalSpace,
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              "Don't have an account? ",
              style: AppTextStyles.customText14(color: AppColors.lightTextColor.withOpacity(0.8)),
            ),
            GestureDetector(
              onTap: () => Get.toNamed(AppRoutes.signUpView),
              child: Text(
                'Sign Up',
                style: AppTextStyles.customText14(
                  color: AppColors.primary,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }
}
