// /// Model for garage signup data with multipart support.
// class BuyCarRequestModel {
//   String? name;
//   File? image;
//
//   BuyCarRequestModel({this.name, this.image});
//
//   Map<String, dynamic> toJson() => {
//         'name': name,
//       };
// }
