// /// Model for garage signup data with multipart support.
// class GarageSignupBodyModel {
//   String? name;
//   File? image;
//
//   GarageSignupBodyModel({this.name, this.image});
//
//   Map<String, dynamic> toJson() => {
//         'name': name,
//       };
// }
