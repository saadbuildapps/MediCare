// /// Model for adding car data with multipart support.
// class AddCarBodyModel {
//   String? model;
//   File? image;
//   File? insuranceDocument;
//   File? inspectionDocument;
//   File? registrationDocument;
//   List<File>? additionalDocuments;
//
//   AddCarBodyModel({
//     this.model,
//     this.image,
//     this.insuranceDocument,
//     this.inspectionDocument,
//     this.registrationDocument,
//     this.additionalDocuments,
//   });
//
//   Map<String, dynamic> toJson() => {
//         'model': model,
//       };
// }
