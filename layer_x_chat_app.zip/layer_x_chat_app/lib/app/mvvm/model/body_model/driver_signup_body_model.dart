// /// Model for driver signup data with multipart support.
// class DriverSignupBodyModel {
//   String? name;
//   String? email;
//   File? image;
//   List<File>? documents;
//   File? details;
//
//   DriverSignupBodyModel({this.name, this.email, this.image, this.documents, this.details});
//
//   Map<String, dynamic> toJson() => {
//         'name': name,
//         'email': email,
//       };
// }
