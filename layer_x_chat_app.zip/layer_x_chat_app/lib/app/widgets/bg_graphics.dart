import 'package:flutter/material.dart';

class BgGraphics extends StatefulWidget {
  const BgGraphics({super.key});

  @override
  State<BgGraphics> createState() => _BgGraphicsState();
}

class _BgGraphicsState extends State<BgGraphics> with TickerProviderStateMixin{
  late Animation<double> _floatingAnimation;
  late AnimationController _floatingController;


  @override
  void initState() {
    super.initState();


    _floatingController = AnimationController(
      duration: const Duration(seconds: 4),
      vsync: this,
    );


    _floatingAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _floatingController,
      curve: Curves.easeInOut,
    ));


  }

  @override
  void dispose() {
    _floatingController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return  Stack(
      children: [
        // Top left floating element
        Positioned(
          top: -30,
          left: -20,
          child: AnimatedBuilder(
            animation: _floatingAnimation,
            builder: (context, child) {
              return Transform.translate(
                offset: Offset(
                  8 * _floatingAnimation.value,
                  6 * _floatingAnimation.value,
                ),
                child: Container(
                  width: 80,
                  height: 80,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    color: const Color(0xFFE2E8F0).withOpacity(0.3),
                  ),
                ),
              );
            },
          ),
        ),

        // Top right floating circle
        Positioned(
          top: 100,
          right: -40,
          child: AnimatedBuilder(
            animation: _floatingAnimation,
            builder: (context, child) {
              return Transform.translate(
                offset: Offset(
                  -10 * _floatingAnimation.value,
                  8 * _floatingAnimation.value,
                ),
                child: Container(
                  width: 100,
                  height: 100,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: const Color(0xFFCBD5E1).withOpacity(0.2),
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }
}


class CustomBackGround extends StatelessWidget {
  final Widget child;
  const CustomBackGround({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    return
      Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFFF8FAFC), Color(0xFFE2E8F0)],
        ),
      ),
      child: Stack(
        children: [
          BgGraphics(),
         child
        ],
      ),
    );
  }
}

