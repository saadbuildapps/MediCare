
import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:flutter_svg/svg.dart';

import '../config/app_colors.dart';
import '../config/app_text_style.dart';

class CustomTextField extends StatefulWidget {
  final String label;
  final String hintText;
  final IconData? iconPath;
  final bool isPassword;

  final TextInputType keyboardType;
  final TextEditingController controller;
  final String? Function(String?)? validator;

  const CustomTextField({
    super.key,
    required this.label,
    required this.hintText,
    required this.controller,
    this.iconPath,
    this.isPassword = false,
    this.keyboardType = TextInputType.text,
    this.validator,
  });

  @override
  State<CustomTextField> createState() => _CustomTextFieldState();
}

class _CustomTextFieldState extends State<CustomTextField> {
  bool _obscureText = true;

  @override
  void initState() {
    super.initState();
    _obscureText = widget.isPassword;
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          widget.label,
          style: AppTextStyles.customText12(
            color: AppColors.black,
            fontWeight: FontWeight.w600,
          ),
        ),
        SizedBox(height: 6.h),
        TextFormField(
          controller: widget.controller,
          obscureText: _obscureText,
          keyboardType: widget.keyboardType,
          validator: widget.validator,
          style: AppTextStyles.customText14(color: AppColors.black),
          decoration: InputDecoration(
            contentPadding: EdgeInsets.symmetric(horizontal: 14.w, vertical: 14.h),
            hintText: widget.hintText,
            hintStyle: AppTextStyles.customText14(
              color: AppColors.textLightBlack,
            ),
            filled: true,
            fillColor: AppColors.white,
            prefixIcon: widget.iconPath != null
                ? Padding(
              padding: EdgeInsets.all(12.sp),
              child: Icon(widget.iconPath!, size: 24.sp),
            )
                : null,
            suffixIcon: widget.isPassword
                ? IconButton(
              icon: Icon(
                _obscureText ? Icons.visibility_off : Icons.visibility,
                color:AppColors.textLightBlack,
              ),
              onPressed: () {
                setState(() => _obscureText = !_obscureText);
              },
            )
                : null,
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12.r),
              borderSide: BorderSide(color: AppColors.textLightBlack),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12.r),
              borderSide: BorderSide(color: AppColors.primary),
            ),
            focusedErrorBorder:OutlineInputBorder(
    borderRadius: BorderRadius.circular(12.r),
    borderSide: BorderSide(color: Colors.red),
    ) ,
            errorBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(12.r),
              borderSide: BorderSide(color: Colors.red),
            ),
          ),
        ),
      ],
    );
  }
}
